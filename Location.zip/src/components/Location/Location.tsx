import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { HomeIndicator_ModeLight } from './HomeIndicator_ModeLight/HomeIndicator_ModeLight';
import classes from './Location.module.css';
import { ModeLightTypePhone } from './ModeLightTypePhone/ModeLightTypePhone';
import { SignUpButton } from './SignUpButton/SignUpButton';

interface Props {
  className?: string;
}
/* @figmaId 40:42 */
export const Location: FC<Props> = memo(function Location(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.frame1}></div>
      <div className={classes.rectangle1}></div>
      <div className={classes.rectangle22}></div>
      <div className={classes.searchForYourLocation}>Search for your location</div>
      <div className={classes.useCurrentLocation}>Use current Location</div>
      <SignUpButton className={classes.signUpButton} classes={{ rectangle2: classes.rectangle2 }} />
      <div className={classes.rectangle6}></div>
      <div className={classes.location}>Location</div>
      <div className={classes.unnamed}>&lt;</div>
      <div className={classes.rectangle4}></div>
      <div className={classes.rectangle5}></div>
      <ModeLightTypePhone className={classes.modeLightTypePhone} />
      <HomeIndicator_ModeLight className={classes.homeIndicator} />
    </div>
  );
});

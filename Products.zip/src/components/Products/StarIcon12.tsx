import { memo, SVGProps } from 'react';

const StarIcon12 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 20 23' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M10 0L12.8801 6.94119L19.5106 7.9463L14.6602 13.2413L15.8779 20.8037L10 17.135L4.12215 20.8037L5.33982 13.2413L0.489435 7.9463L7.11985 6.94119L10 0Z'
      fill='#E0B851'
    />
  </svg>
);
const Memo = memo(StarIcon12);
export { Memo as StarIcon12 };

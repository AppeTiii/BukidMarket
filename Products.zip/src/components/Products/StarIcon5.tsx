import { memo, SVGProps } from 'react';

const StarIcon5 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 21 23' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M10.5 0L13.5242 6.94119L20.4861 7.9463L15.3932 13.2413L16.6717 20.8037L10.5 17.135L4.32825 20.8037L5.60681 13.2413L0.513906 7.9463L7.47584 6.94119L10.5 0Z'
      fill='#E0B851'
    />
  </svg>
);
const Memo = memo(StarIcon5);
export { Memo as StarIcon5 };

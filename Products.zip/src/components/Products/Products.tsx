import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { HomeIndicator_ModeLight } from './HomeIndicator_ModeLight/HomeIndicator_ModeLight';
import { ModeLightTypePhone } from './ModeLightTypePhone/ModeLightTypePhone';
import classes from './Products.module.css';
import { StarIcon2 } from './StarIcon2.js';
import { StarIcon3 } from './StarIcon3.js';
import { StarIcon4 } from './StarIcon4.js';
import { StarIcon5 } from './StarIcon5.js';
import { StarIcon6 } from './StarIcon6.js';
import { StarIcon7 } from './StarIcon7.js';
import { StarIcon8 } from './StarIcon8.js';
import { StarIcon9 } from './StarIcon9.js';
import { StarIcon10 } from './StarIcon10.js';
import { StarIcon11 } from './StarIcon11.js';
import { StarIcon12 } from './StarIcon12.js';
import { StarIcon13 } from './StarIcon13.js';
import { StarIcon14 } from './StarIcon14.js';
import { StarIcon15 } from './StarIcon15.js';
import { StarIcon16 } from './StarIcon16.js';
import { StarIcon17 } from './StarIcon17.js';
import { StarIcon18 } from './StarIcon18.js';
import { StarIcon19 } from './StarIcon19.js';
import { StarIcon20 } from './StarIcon20.js';
import { StarIcon } from './StarIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 40:101 */
export const Products: FC<Props> = memo(function Products(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.rectangle19}></div>
      <div className={classes.rectangle20}></div>
      <div className={classes.addToCart}>Add to Cart</div>
      <div className={classes.unnamed}>+</div>
      <div className={classes.rectangle21}></div>
      <div className={classes.unnamed2}>-</div>
      <div className={classes._1000}>₱100.00</div>
      <div className={classes.rectangle1}></div>
      <div className={classes.rectangle22}></div>
      <div className={classes.rectangle2}></div>
      <div className={classes.logo}>logo</div>
      <div className={classes.rectangle11}></div>
      <div className={classes.rectangle112}></div>
      <div className={classes.rectangle4}></div>
      <div className={classes.rectangle5}></div>
      <div className={classes.addToCart2}>Add to Cart</div>
      <div className={classes.unnamed3}>+</div>
      <div className={classes.productName}>Product Name</div>
      <div className={classes.rectangle12}></div>
      <div className={classes.unnamed4}>-</div>
      <div className={classes._10002}>₱100.00</div>
      <div className={classes.rectangle16}></div>
      <div className={classes.rectangle17}></div>
      <div className={classes.addToCart3}>Add to Cart</div>
      <div className={classes.unnamed5}>+</div>
      <div className={classes.rectangle18}></div>
      <div className={classes.unnamed6}>-</div>
      <div className={classes._10003}>₱100.00</div>
      <div className={classes.rectangle13}></div>
      <div className={classes.productName2}>Product Name</div>
      <div className={classes.productName3}>Product Name</div>
      <div className={classes.productName4}>Product Name</div>
      <div className={classes.rectangle14}></div>
      <div className={classes.addToCart4}>Add to Cart</div>
      <div className={classes.unnamed7}>+</div>
      <div className={classes.rectangle15}></div>
      <div className={classes.unnamed8}>-</div>
      <div className={classes._10004}>₱100.00</div>
      <div className={classes.image1}></div>
      <ModeLightTypePhone className={classes.modeLightTypePhone} />
      <HomeIndicator_ModeLight className={classes.homeIndicator} />
      <div className={classes.star}>
        <StarIcon className={classes.icon} />
      </div>
      <div className={classes.star2}>
        <StarIcon2 className={classes.icon2} />
      </div>
      <div className={classes.star3}>
        <StarIcon3 className={classes.icon3} />
      </div>
      <div className={classes.star4}>
        <StarIcon4 className={classes.icon4} />
      </div>
      <div className={classes.star5}>
        <StarIcon5 className={classes.icon5} />
      </div>
      <div className={classes.star6}>
        <StarIcon6 className={classes.icon6} />
      </div>
      <div className={classes.star7}>
        <StarIcon7 className={classes.icon7} />
      </div>
      <div className={classes.star8}>
        <StarIcon8 className={classes.icon8} />
      </div>
      <div className={classes.star9}>
        <StarIcon9 className={classes.icon9} />
      </div>
      <div className={classes.star10}>
        <StarIcon10 className={classes.icon10} />
      </div>
      <div className={classes.star11}>
        <StarIcon11 className={classes.icon11} />
      </div>
      <div className={classes.star12}>
        <StarIcon12 className={classes.icon12} />
      </div>
      <div className={classes.star13}>
        <StarIcon13 className={classes.icon13} />
      </div>
      <div className={classes.star14}>
        <StarIcon14 className={classes.icon14} />
      </div>
      <div className={classes.star15}>
        <StarIcon15 className={classes.icon15} />
      </div>
      <div className={classes.star16}>
        <StarIcon16 className={classes.icon16} />
      </div>
      <div className={classes.star17}>
        <StarIcon17 className={classes.icon17} />
      </div>
      <div className={classes.star18}>
        <StarIcon18 className={classes.icon18} />
      </div>
      <div className={classes.star19}>
        <StarIcon19 className={classes.icon19} />
      </div>
      <div className={classes.star20}>
        <StarIcon20 className={classes.icon20} />
      </div>
      <div className={classes.unnamed9}>&lt;</div>
    </div>
  );
});

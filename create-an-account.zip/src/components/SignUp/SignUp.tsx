import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Frame1434Icon } from './Frame1434Icon.js';
import { GroupIcon } from './GroupIcon.js';
import { HomeIndicator_ModeLight } from './HomeIndicator_ModeLight/HomeIndicator_ModeLight';
import { ModeLightTypePhone } from './ModeLightTypePhone/ModeLightTypePhone';
import { OIcon } from './OIcon.js';
import classes from './SignUp.module.css';
import { SignUpButton } from './SignUpButton/SignUpButton';
import { VectorIcon2 } from './VectorIcon2.js';
import { VectorIcon3 } from './VectorIcon3.js';
import { VectorIcon4 } from './VectorIcon4.js';
import { VectorIcon5 } from './VectorIcon5.js';
import { VectorIcon6 } from './VectorIcon6.js';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 40:23 */
export const SignUp: FC<Props> = memo(function SignUp(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.alreadyHaveAnAccount}>Already have an account?</div>
      <div className={classes.logIn}>Log In</div>
      <ModeLightTypePhone className={classes.modeLightTypePhone} />
      <HomeIndicator_ModeLight className={classes.homeIndicator} />
      <SignUpButton className={classes.signUpButton} classes={{ rectangle2: classes.rectangle2 }} />
      <div className={classes.logo}>
        <div className={classes.frame}>
          <div className={classes.frame2}>
            <div className={classes.group}></div>
            <div className={classes.frame3}>
              <div className={classes.group2}>
                <GroupIcon className={classes.icon} />
              </div>
              <div className={classes.frame4}>
                <div className={classes.frame5}>
                  <div className={classes.frame6}>
                    <div className={classes.textblock}>
                      <div className={classes.frame7}>
                        <div className={classes.frame8}>
                          <div className={classes.o}>
                            <OIcon className={classes.icon2} />
                          </div>
                        </div>
                        <div className={classes.vector}>
                          <VectorIcon className={classes.icon3} />
                        </div>
                        <div className={classes.vector2}>
                          <VectorIcon2 className={classes.icon4} />
                        </div>
                        <div className={classes.vector3}>
                          <VectorIcon3 className={classes.icon5} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.createAnAccount}>Create an Account</div>
      <div className={classes.rectangle1}></div>
      <div className={classes.vector4}>
        <VectorIcon4 className={classes.icon6} />
      </div>
      <div className={classes.Yourname}>@yourname</div>
      <div className={classes.emailAdress}>Email Adress</div>
      <div className={classes.yourName}>Your Name</div>
      <div className={classes.password}>Password</div>
      <div className={classes.rectangle12}></div>
      <div className={classes.vector5}>
        <VectorIcon5 className={classes.icon7} />
      </div>
      <div className={classes.frame1434}>
        <Frame1434Icon className={classes.icon8} />
      </div>
      <div className={classes.strong}>Strong</div>
      <div className={classes.rectangle6}></div>
      <div className={classes.rectangle7}></div>
      <div className={classes.rectangle8}></div>
      <div className={classes.rectangle13}></div>
      <div className={classes.yournameGmailCom}>yourname@gmail.com</div>
      <div className={classes.vector6}>
        <VectorIcon6 className={classes.icon9} />
      </div>
    </div>
  );
});

import { memo, SVGProps } from 'react';

const VectorIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 176 14' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0.91198 6.94681C0.91198 3.177 4.12495 0.121201 8.08864 0.121201C12.0523 0.121201 15.2653 3.177 15.2653 6.94681C15.2653 10.7166 12.0523 13.7724 8.08864 13.7724C4.12495 13.7724 0.91198 10.7166 0.91198 6.94681ZM161.36 6.94681C161.36 3.177 164.573 0.121201 168.536 0.121201C172.5 0.121201 175.713 3.177 175.713 6.94681C175.713 10.7166 172.5 13.7724 168.536 13.7724C164.573 13.7724 161.36 10.7166 161.36 6.94681Z'
      fill='#124948'
    />
  </svg>
);
const Memo = memo(VectorIcon3);
export { Memo as VectorIcon3 };

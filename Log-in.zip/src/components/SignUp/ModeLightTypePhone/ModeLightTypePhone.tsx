import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { Time_ModeLightTypeDefault } from '../Time_ModeLightTypeDefault/Time_ModeLightTypeDefault';
import classes from './ModeLightTypePhone.module.css';
import { NotchIcon } from './NotchIcon.js';
import { RightSideIcon } from './RightSideIcon.js';
import { TimeIcon } from './TimeIcon.js';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
}
/* @figmaId 40:202 */
export const ModeLightTypePhone: FC<Props> = memo(function ModeLightTypePhone(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.iPhoneXOrNewerLightDefault}>
        <div className={classes.notch}>
          <NotchIcon className={classes.icon} />
        </div>
        <div className={classes.rightSide}>
          <RightSideIcon className={classes.icon2} />
        </div>
        <Time_ModeLightTypeDefault className={classes.time} />
      </div>
    </div>
  );
});

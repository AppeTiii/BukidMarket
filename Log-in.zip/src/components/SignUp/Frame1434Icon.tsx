import { memo, SVGProps } from 'react';

const Frame1434Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 79 7' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={2.85788} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={11.0835} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={19.3091} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={27.5347} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={35.7603} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={43.9859} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={52.2115} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={60.4372} cy={3.29597} r={2.59756} fill='#124948' />
    <circle cx={68.6628} cy={3.29597} r={2.59756} fill='#124948' />
  </svg>
);
const Memo = memo(Frame1434Icon);
export { Memo as Frame1434Icon };

import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './SignUpButton.module.css';

interface Props {
  className?: string;
  classes?: {
    rectangle2?: string;
    root?: string;
  };
  text?: {
    signUp?: ReactNode;
  };
}
/* @figmaId 47:202 */
export const SignUpButton: FC<Props> = memo(function SignUpButton(props = {}) {
  return (
    <button
      className={`${resets.storybrainResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}
    >
      <div className={`${props.classes?.rectangle2 || ''} ${classes.rectangle2}`}></div>
      {props.text?.signUp != null ? props.text?.signUp : <div className={classes.signUp}>Sign Up</div>}
    </button>
  );
});

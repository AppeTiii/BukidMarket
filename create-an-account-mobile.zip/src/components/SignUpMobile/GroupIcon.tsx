import { memo, SVGProps } from 'react';

const GroupIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 203 192' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0.5625 96C0.5625 42.9804 45.7535 0 101.5 0C157.247 0 202.438 42.9804 202.438 96C202.438 149.02 157.247 192 101.5 192C45.7535 192 0.5625 149.02 0.5625 96ZM101.5 190.718C156.501 190.718 201.089 148.311 201.089 96C201.089 43.689 156.501 1.2822 101.5 1.2822C46.4985 1.2822 1.91065 43.689 1.91065 96C1.91065 148.311 46.4985 190.718 101.5 190.718Z'
      fill='#124948'
    />
  </svg>
);
const Memo = memo(GroupIcon);
export { Memo as GroupIcon };

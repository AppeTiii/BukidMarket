import { memo, SVGProps } from 'react';

const ChevronLeftIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 13 23' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M11.8892 20.4666C12.3951 21.0329 12.3439 21.9001 11.7746 22.4034C11.2301 22.8849 10.409 22.8592 9.89576 22.3605L9.82774 22.2895L1.19149 12.6237C0.619506 11.9835 0.619506 11.0165 1.19149 10.3763L9.82774 0.710491C10.3337 0.144173 11.2054 0.0931634 11.7746 0.596556C12.3191 1.07806 12.3897 1.8924 11.952 2.45792L11.8892 2.53344L4.2124 11.1254C4.02174 11.3388 4.02174 11.6612 4.2124 11.8746L11.8892 20.4666Z'
      fill='#333333'
    />
  </svg>
);
const Memo = memo(ChevronLeftIcon);
export { Memo as ChevronLeftIcon };

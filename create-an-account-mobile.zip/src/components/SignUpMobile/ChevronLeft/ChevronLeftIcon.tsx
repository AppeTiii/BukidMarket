import { memo, SVGProps } from 'react';

const ChevronLeftIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 22 40' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M20.5807 35.9406C21.4803 36.9473 21.3891 38.489 20.3771 39.3839C19.4091 40.2399 17.9493 40.1942 17.0369 39.3075L16.916 39.1814L1.56264 21.9977C0.545787 20.8596 0.545787 19.1404 1.56264 18.0023L16.916 0.81865C17.8155 -0.188136 19.3651 -0.278821 20.3771 0.6161C21.3451 1.47211 21.4706 2.91983 20.6924 3.92519L20.5807 4.05944L6.93316 19.3341C6.59421 19.7135 6.59421 20.2865 6.93316 20.6659L20.5807 35.9406Z'
      fill='#333333'
    />
  </svg>
);
const Memo = memo(ChevronLeftIcon);
export { Memo as ChevronLeftIcon };

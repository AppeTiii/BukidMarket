import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { ChevronLeft } from './ChevronLeft/ChevronLeft';
import { ChevronLeftIcon } from './ChevronLeftIcon.js';
import { Contact } from './Contact/Contact';
import { ContactIcon } from './ContactIcon.js';
import { GroupIcon } from './GroupIcon.js';
import { HomeIndicator_ModeLight } from './HomeIndicator_ModeLight/HomeIndicator_ModeLight';
import { ModeLightTypePhone } from './ModeLightTypePhone/ModeLightTypePhone';
import { OIcon } from './OIcon.js';
import { Phone } from './Phone/Phone';
import { PhoneIcon } from './PhoneIcon.js';
import { SignUpButton } from './SignUpButton/SignUpButton';
import classes from './SignUpMobile.module.css';
import { VectorIcon2 } from './VectorIcon2.js';
import { VectorIcon3 } from './VectorIcon3.js';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 84:233 */
export const SignUpMobile: FC<Props> = memo(function SignUpMobile(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <ModeLightTypePhone className={classes.modeLightTypePhone} />
      <HomeIndicator_ModeLight className={classes.homeIndicator} />
      <SignUpButton
        className={classes.enterButton}
        classes={{ rectangle2: classes.rectangle2 }}
        text={{
          signUp: <div className={classes.enter}>Enter</div>,
        }}
      />
      <div className={classes.logo}>
        <div className={classes.frame}>
          <div className={classes.frame2}>
            <div className={classes.group}></div>
            <div className={classes.frame3}>
              <div className={classes.group2}>
                <GroupIcon className={classes.icon5} />
              </div>
              <div className={classes.frame4}>
                <div className={classes.frame5}>
                  <div className={classes.frame6}>
                    <div className={classes.textblock}>
                      <div className={classes.frame7}>
                        <div className={classes.frame8}>
                          <div className={classes.o}>
                            <OIcon className={classes.icon6} />
                          </div>
                        </div>
                        <div className={classes.vector}>
                          <VectorIcon className={classes.icon7} />
                        </div>
                        <div className={classes.vector2}>
                          <VectorIcon2 className={classes.icon8} />
                        </div>
                        <div className={classes.vector3}>
                          <VectorIcon3 className={classes.icon9} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.enterContactDetails}>Enter Contact Details:</div>
      <div className={classes.rectangle1}></div>
      <div className={classes._63XXXXXXXXXX}>(+63) XXX-XXXX-XXX</div>
      <div className={classes.phoneNumber}>Phone Number</div>
      <div className={classes.mobileNumber}>Mobile Number</div>
      <div className={classes.rectangle12}></div>
      <div className={classes._2XXXXXXX}>(02) XXX-XX-XX</div>
      <Phone
        className={classes.phone}
        swap={{
          icon: <PhoneIcon className={classes.icon} />,
        }}
      />
      <ChevronLeft
        className={classes.chevronLeft}
        swap={{
          icon: <ChevronLeftIcon className={classes.icon2} />,
        }}
      />
      <Contact
        className={classes.contact}
        classes={{ icon: classes.icon3 }}
        swap={{
          icon: (
            <div className={classes.icon3}>
              <ContactIcon className={classes.icon4} />
            </div>
          ),
        }}
      />
    </div>
  );
});

import { memo, SVGProps } from 'react';

const Heart2Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 21' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M25 6.22494C25 2.74118 22.1311 0 18.5959 0C15.7413 0 13.3265 1.88255 12.4993 4.4262C11.6714 1.88288 9.25662 0.0655117 6.40199 0.0655117C2.8661 0.0655117 0 2.72855 0 6.21364C0 7.97215 0.731983 9.21454 1.91004 10.5441L12.5052 21L23.0882 10.5441C24.2673 9.21454 25 7.98212 25 6.22494Z'
      fill='white'
      stroke='black'
    />
  </svg>
);
const Memo = memo(Heart2Icon2);
export { Memo as Heart2Icon2 };
